/**
 * Niklas Romero
 *CS2321/assignment1
 * The class implements a queue to create a circular array queue
 */
package cs2321;

import net.datastructures.Queue;

/**
 * @author ruihong-adm
 * @param <E>
 *
 */
public class CircularArrayQueue<E> implements Queue<E> {
	private int size;
	private E[] elements;
	private int queueSize;
	private int rear;
	private int front;
	/*
	 * creates the  circular array queue
	 * @param queue size int value
	 */
	public CircularArrayQueue(int queueSize) {
		this.queueSize = queueSize;
			elements = (E[]) new Object[this.queueSize];
			size = 0;
			front = -1;
			rear = -1;
		
	}
	/*
	 * gives the size of the circular array queue
	 * @return size  int value
	 */
	@Override
	public int size() {
		return size;
	}
	/*
	 * checks if the circular queue is empty
	 * @return bool if circular queue is empty
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}
	
	/*
	 * adds an element to the circular queue
	 * @param e element
	 */
	@Override
	public void enqueue(E e) {
		rear = (rear +1) % elements.length;
		 elements[rear] = e;
         size++;
         
         if (front == -1) {
				front = rear;
			}
	}
	
	/*
	 * gets first element of the circular array 
	 * @return first element of the circular array
	 */
	@Override
	public E first() 
	{
		if(isEmpty())
		{
			return null;
		}
		else
		{
		return elements[front];
		}
		
	}
	/*
	 * removes element from queue
	 * @return e element that was removed
	 */
	@Override
	public E dequeue() {
		E deQueuedElement;
		 deQueuedElement = elements[front];
         elements[front] = null;
         front = (front + 1) % elements.length;
         size--;
     
     return deQueuedElement;
	}
    
}
